module Bourbon
  VERSION = "4.2.3"
end
